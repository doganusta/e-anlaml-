# Eş ve Zıt Anlamlı Kelimeler Doğru–Yanlış Etkinliği

Bu depo, 2. sınıf Türkçe dersi için hazırlanmış basit bir web etkinliğini içerir.

## Yayınlamak için
1. Bu dosyaları bir GitHub deposuna yükleyin.
2. **Settings → Pages** bölümüne gidin.
3. *Deploy from branch* kısmında **main** ve **/(root)** konumunu seçip kaydedin.
4. GitHub Pages size `https://kullaniciadiniz.github.io/depo-adi/` biçiminde bir bağlantı verecektir.